/* MagicMirror² Deprecated Config Options List
 *
 * By Michael Teeuw https://michaelteeuw.nl
 * MIT Licensed.
 *
 * Olex S. original idea this deprecated option
 */

module.exports = {
	configs: ["kioskmode"]
};
